<!DOCTYPE html>

<title> My Blog</title>

<link rel="stylesheet" href="/app.css">



<body>
    <!-- @yield('content') -->
    {{ $slot}}
</body>
