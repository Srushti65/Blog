<!DOCTYPE html>

<title> My Blog</title>

<link rel="stylesheet" href="/app.css">



<body>
    <!-- <?php echo $__env->yieldContent('content'); ?> -->
    <?php echo e($slot); ?>

</body>
<?php /**PATH /home/clientjoy/laravel/blog/resources/views/components/layout.blade.php ENDPATH**/ ?>